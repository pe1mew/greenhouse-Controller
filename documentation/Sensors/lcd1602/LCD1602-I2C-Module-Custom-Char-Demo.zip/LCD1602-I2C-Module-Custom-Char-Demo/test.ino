#include <Wire.h>
#include "Waveshare_LCD1602.h"

Waveshare_LCD1602 lcd(16,2);  //16 characters and 2 lines of show
int r,g,b,t=0;

uint8_t bell[8]  = {0x4,0xe,0xe,0xe,0x1f,0x0,0x4};
uint8_t note[8]  = {0x2,0x3,0x2,0xe,0x1e,0xc,0x0};
uint8_t clock[8] = {0x0,0xe,0x15,0x17,0x11,0xe,0x0};
uint8_t heart[8] = {0x0,0xa,0x1f,0x1f,0xe,0x4,0x0};
uint8_t duck[8]  = {0x0,0xc,0x1d,0xf,0xf,0x6,0x0};
uint8_t check[8] = {0x0,0x1,0x3,0x16,0x1c,0x8,0x0};
uint8_t cross[8] = {0x0,0x1b,0xe,0x4,0xe,0x1b,0x0};
uint8_t retarrow[8] = {	0x1,0x1,0x5,0x9,0x1f,0x8,0x4};

void setup() {
    // initialize
    lcd.init();
    
    lcd.customSymbol(0, bell);
    lcd.customSymbol(1, note);
    lcd.customSymbol(2, clock);
    lcd.customSymbol(3, heart);
    lcd.customSymbol(4, duck);
    lcd.customSymbol(5, check);
    lcd.customSymbol(6, cross);
    lcd.customSymbol(7, retarrow);

    
    lcd.setCursor(0,0);
    lcd.send_string("I ");
    lcd.write_char(3);
    lcd.send_string(" Waveshare");
    lcd.setCursor(0,1);
    lcd.send_string("Hello world!!!");
    delay(5000);
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.write_char(0);
    lcd.write_char(1);
    lcd.write_char(2);
    lcd.write_char(3);
    lcd.write_char(4);
    lcd.write_char(5);
    lcd.write_char(6);
    lcd.write_char(7);
}

void loop() {
    delay(150);
}
